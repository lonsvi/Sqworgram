﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace _1ДЛЯ_ТЕСТА_ДИЗАЙНА_ПРОСТО
{
    public class User
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string AvatarUrl { get; set; }
    }

    public class DatabaseHelper
    {
        private readonly string connectionString = @"Server=tipesoto.beget.app;Port=3306;Database=default-db;User=default-db;Password=lS1%uLnz1&*O";

        public DatabaseHelper()
        {
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string createUsersTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Users (
                        Id INT AUTO_INCREMENT PRIMARY KEY,
                        Login VARCHAR(255) NOT NULL UNIQUE,
                        Password VARCHAR(255) NOT NULL,
                        AvatarUrl TEXT,
                        IsOnline BOOLEAN DEFAULT FALSE,
                        LastSeen DATETIME,
                        IsTyping BOOLEAN DEFAULT FALSE
                    )";
                using (var command = new MySqlCommand(createUsersTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }

                string createChatsTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Chats (
                        Id INT AUTO_INCREMENT PRIMARY KEY,
                        User1Id INT NOT NULL,
                        User2Id INT NOT NULL,
                        FOREIGN KEY (User1Id) REFERENCES Users(Id),
                        FOREIGN KEY (User2Id) REFERENCES Users(Id)
                    )";
                using (var command = new MySqlCommand(createChatsTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }

                string createMessagesTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Messages (
                        Id INT AUTO_INCREMENT PRIMARY KEY,
                        ChatId INT NOT NULL,
                        SenderId INT NOT NULL,
                        MessageText TEXT NOT NULL,
                        Timestamp DATETIME NOT NULL,
                        FOREIGN KEY (ChatId) REFERENCES Chats(Id),
                        FOREIGN KEY (SenderId) REFERENCES Users(Id)
                    )";
                using (var command = new MySqlCommand(createMessagesTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }

                string createFavoriteChatsTableQuery = @"
                    CREATE TABLE IF NOT EXISTS FavoriteChats (
                        UserId INT NOT NULL,
                        ChatId INT NOT NULL,
                        PRIMARY KEY (UserId, ChatId),
                        FOREIGN KEY (UserId) REFERENCES Users(Id),
                        FOREIGN KEY (ChatId) REFERENCES Chats(Id)
                    )";
                using (var command = new MySqlCommand(createFavoriteChatsTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        public void AddFavoriteChat(int userId, int chatId)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT IGNORE INTO FavoriteChats (UserId, ChatId) VALUES (@UserId, @ChatId)";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.Parameters.AddWithValue("@ChatId", chatId);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void RemoveFavoriteChat(int userId, int chatId)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "DELETE FROM FavoriteChats WHERE UserId = @UserId AND ChatId = @ChatId";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.Parameters.AddWithValue("@ChatId", chatId);
                    command.ExecuteNonQuery();
                }
            }
        }

        public List<int> GetFavoriteChats(int userId)
        {
            var favoriteChats = new List<int>();
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT ChatId FROM FavoriteChats WHERE UserId = @UserId";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            favoriteChats.Add(reader.GetInt32(0));
                        }
                    }
                }
            }
            return favoriteChats;
        }

        public User GetUserById(int userId)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Id, Login, AvatarUrl FROM Users WHERE Id = @UserId";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new User
                            {
                                Id = reader.GetInt32("Id"),
                                Login = reader.GetString("Login"),
                                AvatarUrl = reader.IsDBNull(reader.GetOrdinal("AvatarUrl")) ? null : reader.GetString("AvatarUrl")
                            };
                        }
                    }
                }
            }
            return null;
        }

        public bool RegisterUser(string login, string password)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Users (Login, Password) VALUES (@Login, @Password)";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    command.Parameters.AddWithValue("@Password", password);
                    try
                    {
                        command.ExecuteNonQuery();
                        return true;
                    }
                    catch (MySqlException)
                    {
                        return false;
                    }
                }
            }
        }

        public (int? UserId, string Login, string AvatarUrl) LoginUser(string login, string password)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Id, Login, AvatarUrl FROM Users WHERE Login = @Login AND Password = @Password";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    command.Parameters.AddWithValue("@Password", password);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string avatarUrl = reader.IsDBNull(2) ? null : reader.GetString(2);
                            return (reader.GetInt32(0), reader.GetString(1), avatarUrl);
                        }
                    }
                }
            }
            return (null, null, null);
        }

        public List<(int Id, string Login, string AvatarUrl, bool IsOnline, DateTime? LastSeen, bool IsTyping)> GetUsers(int excludeUserId)
        {
            var users = new List<(int Id, string Login, string AvatarUrl, bool IsOnline, DateTime? LastSeen, bool IsTyping)>();
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Id, Login, AvatarUrl, IsOnline, LastSeen, IsTyping FROM Users WHERE Id != @UserId";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", excludeUserId);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string avatarUrl = reader.IsDBNull(2) ? null : reader.GetString(2);
                            bool isOnline = reader.GetBoolean(3);
                            DateTime? lastSeen = reader.IsDBNull(4) ? (DateTime?)null : reader.GetDateTime(4);
                            bool isTyping = reader.GetBoolean(5);
                            users.Add((reader.GetInt32(0), reader.GetString(1), avatarUrl, isOnline, lastSeen, isTyping));
                        }
                    }
                }
            }
            return users;
        }

        public void UpdateAvatarUrl(int userId, string avatarUrl)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "UPDATE Users SET AvatarUrl = @AvatarUrl WHERE Id = @UserId";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@AvatarUrl", (object)avatarUrl ?? DBNull.Value);
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.ExecuteNonQuery();
                }
            }
        }

        public int GetOrCreateChat(int user1Id, int user2Id)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Id FROM Chats WHERE (User1Id = @User1Id AND User2Id = @User2Id) OR (User1Id = @User2Id AND User2Id = @User1Id)";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@User1Id", user1Id);
                    command.Parameters.AddWithValue("@User2Id", user2Id);
                    var result = command.ExecuteScalar();
                    if (result != null)
                    {
                        return Convert.ToInt32(result);
                    }
                }

                string insertQuery = "INSERT INTO Chats (User1Id, User2Id) VALUES (@User1Id, @User2Id); SELECT LAST_INSERT_ID();";
                using (var command = new MySqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@User1Id", user1Id);
                    command.Parameters.AddWithValue("@User2Id", user2Id);
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        public void SaveMessage(int chatId, int senderId, string messageText, DateTime timestamp)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Messages (ChatId, SenderId, MessageText, Timestamp) VALUES (@ChatId, @SenderId, @MessageText, @Timestamp)";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ChatId", chatId);
                    command.Parameters.AddWithValue("@SenderId", senderId);
                    command.Parameters.AddWithValue("@MessageText", messageText);
                    command.Parameters.AddWithValue("@Timestamp", timestamp);
                    command.ExecuteNonQuery();
                }
            }
        }

        public List<(int SenderId, string MessageText, DateTime Timestamp)> GetMessages(int chatId)
        {
            var messages = new List<(int SenderId, string MessageText, DateTime Timestamp)>();
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT SenderId, MessageText, Timestamp FROM Messages WHERE ChatId = @ChatId ORDER BY Timestamp";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ChatId", chatId);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            messages.Add((
                                reader.GetInt32(0),
                                reader.GetString(1),
                                reader.GetDateTime(2)
                            ));
                        }
                    }
                }
            }
            return messages;
        }

        public List<(int SenderId, string MessageText, DateTime Timestamp)> GetMessagesAfter(int chatId, DateTime afterTime)
        {
            var messages = new List<(int SenderId, string MessageText, DateTime Timestamp)>();
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT SenderId, MessageText, Timestamp FROM Messages WHERE ChatId = @ChatId AND Timestamp > @AfterTime ORDER BY Timestamp ASC";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ChatId", chatId);
                    command.Parameters.AddWithValue("@AfterTime", afterTime);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            messages.Add((
                                reader.GetInt32(0),
                                reader.GetString(1),
                                reader.GetDateTime(2)
                            ));
                        }
                    }
                }
            }
            return messages;
        }

        public void SetUserOnline(int userId, bool isOnline)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "UPDATE Users SET IsOnline = @IsOnline, LastSeen = @LastSeen WHERE Id = @UserId";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@IsOnline", isOnline);
                    command.Parameters.AddWithValue("@LastSeen", isOnline ? (object)DBNull.Value : DateTime.Now);
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void SetUserTyping(int userId, bool isTyping)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "UPDATE Users SET IsTyping = @IsTyping WHERE Id = @UserId";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@IsTyping", isTyping);
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.ExecuteNonQuery();
                }
            }
        }

        public (bool IsOnline, DateTime? LastSeen, bool IsTyping) GetUserStatus(int userId)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT IsOnline, LastSeen, IsTyping FROM Users WHERE Id = @UserId";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            bool isOnline = reader.GetBoolean(0);
                            DateTime? lastSeen = reader.IsDBNull(1) ? (DateTime?)null : reader.GetDateTime(1);
                            bool isTyping = reader.GetBoolean(2);
                            return (isOnline, lastSeen, isTyping);
                        }
                    }
                }
            }
            return (false, null, false);
        }
    }
}