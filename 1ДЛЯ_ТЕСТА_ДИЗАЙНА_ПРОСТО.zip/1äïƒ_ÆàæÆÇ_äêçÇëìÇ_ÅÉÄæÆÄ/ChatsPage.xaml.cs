﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Threading;

namespace _1ДЛЯ_ТЕСТА_ДИЗАЙНА_ПРОСТО
{
    public partial class ChatsPage : Page
    {
        private readonly DatabaseHelper dbHelper;
        private readonly int currentUserId;
        private readonly string currentUserLogin;
        private string currentAvatarUrl;
        private int currentChatId = -1;
        private int otherUserId = -1;
        private readonly Dictionary<string, int> chatMapping = new Dictionary<string, int>();
        private DispatcherTimer messageTimer;
        private DispatcherTimer statusTimer;
        private int displayedMessageCount = 0;
        private readonly TranslationService translationService;
        private bool isFavoriteMode = false;
        private readonly Dictionary<int, BitmapImage> avatarImageCache = new Dictionary<int, BitmapImage>(); // Кэш для изображений аватаров
        private readonly Dictionary<int, List<UIElement>> messageUICache = new Dictionary<int, List<UIElement>>(); // Кэш для UI сообщений

        public ChatsPage(int userId, string userLogin, string avatarUrl = null)
        {
            InitializeComponent();
            dbHelper = new DatabaseHelper();
            currentUserId = userId;
            currentUserLogin = userLogin;
            currentAvatarUrl = avatarUrl;
            translationService = new TranslationService();

            messageTimer = new DispatcherTimer();
            messageTimer.Interval = TimeSpan.FromSeconds(5);
            messageTimer.Tick += MessageTimer_Tick;

            statusTimer = new DispatcherTimer();
            statusTimer.Interval = TimeSpan.FromSeconds(2);
            statusTimer.Tick += StatusTimer_Tick;

            Loaded += ChatsPage_Loaded;
            MessageTextBox.TextChanged += MessageTextBox_TextChanged;

            dbHelper.SetUserOnline(currentUserId, true);
        }

        private void ChatsPage_Loaded(object sender, RoutedEventArgs e)
        {
            var currentUser = dbHelper.GetUserById(currentUserId);
            if (currentUser != null)
            {
                currentAvatarUrl = currentUser.AvatarUrl;
            }
            LoadChats();

            // Выбираем первый чат только после полной загрузки страницы
            if (ChatListBox.Items.Count > 0 && ChatListBox.SelectedItem == null)
            {
                ChatListBox.SelectedIndex = 0;
            }

            statusTimer.Start();
        }

        private void MessageTimer_Tick(object sender, EventArgs e)
        {
            if (currentChatId != -1)
            {
                LoadNewMessages();
            }
        }

        private void StatusTimer_Tick(object sender, EventArgs e)
        {
            LoadChats();
            if (currentChatId != -1 && otherUserId != -1)
            {
                var (isOnline, lastSeen, isTyping) = dbHelper.GetUserStatus(otherUserId);
                if (TypingIndicator != null)
                {
                    TypingIndicator.Visibility = isTyping ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }

        private void LoadNewMessages()
        {
            var messagesInDb = dbHelper.GetMessages(currentChatId);
            if (messagesInDb.Count != displayedMessageCount)
            {
                string selectedChat = ((dynamic)ChatListBox.SelectedItem)?.Login;
                if (selectedChat != null)
                {
                    OpenChat(selectedChat);
                }
            }
        }

        private void LoadChats()
        {
            string previouslySelectedChat = null;
            if (ChatListBox.SelectedItem != null)
            {
                var selectedItem = ChatListBox.SelectedItem;
                var loginProperty = selectedItem.GetType().GetProperty("Login");
                if (loginProperty != null)
                {
                    previouslySelectedChat = loginProperty.GetValue(selectedItem) as string;
                }
            }

            ChatListBox.Items.Clear();
            chatMapping.Clear();

            var users = dbHelper.GetUsers(currentUserId);
            var favoriteChats = dbHelper.GetFavoriteChats(currentUserId).ToHashSet();

            foreach (var user in users)
            {
                int chatId = dbHelper.GetOrCreateChat(currentUserId, user.Id);
                if (!isFavoriteMode || (isFavoriteMode && favoriteChats.Contains(chatId)))
                {
                    ChatListBox.Items.Add(new
                    {
                        Login = user.Login,
                        AvatarUrl = user.AvatarUrl,
                        IsOnline = user.IsOnline,
                        LastSeen = user.LastSeen,
                        IsTyping = user.IsTyping
                    });
                    chatMapping[user.Login] = chatId;
                }
            }

            if (ChatListBox.Items.Count > 0)
            {
                if (previouslySelectedChat != null)
                {
                    foreach (var item in ChatListBox.Items)
                    {
                        var loginProperty = item.GetType().GetProperty("Login");
                        if (loginProperty != null && loginProperty.GetValue(item) as string == previouslySelectedChat)
                        {
                            ChatListBox.SelectedItem = item;
                            break;
                        }
                    }
                }
                // Убрали выбор первого элемента здесь, перенесли в ChatsPage_Loaded
            }
            else
            {
                ChatListBox.SelectedItem = null;
                ChatArea.Visibility = Visibility.Collapsed;
                ChatPlaceholder.Visibility = Visibility.Visible;
                currentChatId = -1;
            }
        }

        private void ChatListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            messageTimer.Stop();
            if (ChatListBox.SelectedItem != null)
            {
                var selectedItem = ChatListBox.SelectedItem;
                var loginProperty = selectedItem.GetType().GetProperty("Login");
                if (loginProperty != null)
                {
                    string selectedChat = loginProperty.GetValue(selectedItem) as string;
                    if (selectedChat != null && chatMapping.ContainsKey(selectedChat))
                    {
                        currentChatId = chatMapping[selectedChat];
                        var user = dbHelper.GetUsers(currentUserId).FirstOrDefault(u => u.Login == selectedChat);
                        if (user.Id != 0) // Проверяем, что пользователь найден
                        {
                            otherUserId = user.Id;
                            OpenChat(selectedChat);
                            if (TypingIndicator != null)
                            {
                                TypingIndicator.DataContext = new { SelectedChatLogin = selectedChat };
                            }
                        }
                        else
                        {
                            ChatArea.Visibility = Visibility.Collapsed;
                            ChatPlaceholder.Visibility = Visibility.Visible;
                            currentChatId = -1;
                            otherUserId = -1;
                        }
                    }
                }
            }
            else
            {
                ChatArea.Visibility = Visibility.Collapsed;
                ChatPlaceholder.Visibility = Visibility.Visible;
                currentChatId = -1;
                otherUserId = -1;
            }
        }

        private void OpenChat(string chatName)
        {
            ChatPlaceholder.Visibility = Visibility.Collapsed;
            ChatArea.Visibility = Visibility.Visible;

            // Проверяем, есть ли сообщения в кэше UI
            if (messageUICache.ContainsKey(currentChatId))
            {
                MessagesPanel.Children.Clear();
                foreach (var uiElement in messageUICache[currentChatId])
                {
                    MessagesPanel.Children.Add(uiElement);
                }
                displayedMessageCount = messageUICache[currentChatId].Count;
            }
            else
            {
                MessagesPanel.Children.Clear();
                var messages = dbHelper.GetMessages(currentChatId);
                messages = messages.OrderBy(m => m.Timestamp).ToList();

                var messageUIElements = new List<UIElement>();
                foreach (var message in messages)
                {
                    bool isSentByMe = message.SenderId == currentUserId;
                    var messageUI = AddMessageToUI(message.MessageText, isSentByMe, message.Timestamp);
                    messageUIElements.Add(messageUI);
                }
                messageUICache[currentChatId] = messageUIElements;
                displayedMessageCount = messages.Count;
            }

            messageTimer.Start();
            ChatScrollViewer.ScrollToEnd();
        }

        private UIElement AddMessageToUI(string message, bool isSentByMe, DateTime timestamp)
        {
            StackPanel messageContainer = new StackPanel
            {
                Margin = new Thickness(5),
                HorizontalAlignment = isSentByMe ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                MaxWidth = 450
            };

            StackPanel contentPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = isSentByMe ? HorizontalAlignment.Right : HorizontalAlignment.Left
            };

            Border messageBorder = new Border
            {
                CornerRadius = new CornerRadius(10),
                Background = isSentByMe ? new SolidColorBrush(Color.FromRgb(85, 85, 85)) : new SolidColorBrush(Color.FromRgb(68, 68, 68)),
                Padding = new Thickness(10),
                Margin = new Thickness(0, 2, 5, 2)
            };

            TextBlock messageBlock = new TextBlock
            {
                Text = message,
                Foreground = Brushes.White,
                TextWrapping = TextWrapping.Wrap,
                FontFamily = new FontFamily("Segoe UI"),
                FontSize = 14
            };

            messageBorder.Child = messageBlock;

            Button translateButton = new Button
            {
                Content = "Перевести",
                Style = (Style)FindResource("TranslateButtonStyle"),
                Tag = message
            };
            translateButton.Click += TranslateButton_Click;

            if (isSentByMe)
            {
                contentPanel.Children.Add(translateButton);
                contentPanel.Children.Add(messageBorder);
            }
            else
            {
                contentPanel.Children.Add(messageBorder);
                contentPanel.Children.Add(translateButton);
            }

            TextBlock timestampBlock = new TextBlock
            {
                Text = timestamp.ToString("HH:mm"),
                Foreground = Brushes.Gray,
                FontSize = 10,
                HorizontalAlignment = isSentByMe ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                Margin = new Thickness(0, 0, 0, 5),
                FontFamily = new FontFamily("Segoe UI")
            };

            messageContainer.Children.Add(contentPanel);
            messageContainer.Children.Add(timestampBlock);
            MessagesPanel.Children.Add(messageContainer);

            messageContainer.BeginAnimation(UIElement.OpacityProperty, new System.Windows.Media.Animation.DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = new Duration(TimeSpan.FromSeconds(0.3))
            });

            return messageContainer;
        }

        private async void TranslateButton_Click(object sender, RoutedEventArgs e)
        {
            Button translateButton = sender as Button;
            if (translateButton == null) return;

            string messageText = translateButton.Tag as string;
            if (string.IsNullOrEmpty(messageText))
            {
                MessageBox.Show("Сообщение пустое, нечего переводить.");
                return;
            }

            string direction = (TranslationDirectionComboBox.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "EN → RU";
            string sourceLanguage = direction == "EN → RU" ? "en" : "ru";
            string targetLanguage = direction == "EN → RU" ? "ru" : "en";

            string translatedText = await translationService.TranslateTextAsync(messageText, sourceLanguage, targetLanguage);

            if (translatedText.Contains("INVALID SOURCE LANGUAGE"))
            {
                MessageBox.Show($"Ошибка: Неверный исходный язык ({sourceLanguage}). Попробуйте другой язык.");
                return;
            }

            var buttonParent = translateButton.Parent as StackPanel;
            var messageContainer = buttonParent?.Parent as StackPanel;
            if (messageContainer != null)
            {
                TextBlock translatedBlock = new TextBlock
                {
                    Text = $"[Перевод]: {translatedText}",
                    Foreground = Brushes.LightGray,
                    TextWrapping = TextWrapping.Wrap,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontSize = 12,
                    Margin = new Thickness(10, 0, 0, 5)
                };
                messageContainer.Children.Add(translatedBlock);

                // Обновляем кэш UI
                if (messageUICache.ContainsKey(currentChatId))
                {
                    var messageUI = messageUICache[currentChatId].FirstOrDefault(ui => ui == messageContainer);
                    if (messageUI != null)
                    {
                        messageContainer.Children.Add(translatedBlock);
                    }
                }
            }

            ChatScrollViewer.ScrollToEnd();
        }

        private void SendMessage_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(MessageTextBox.Text) && currentChatId != -1)
            {
                string newMessage = MessageTextBox.Text;
                DateTime timestamp = DateTime.Now;

                dbHelper.SaveMessage(currentChatId, currentUserId, newMessage, timestamp);
                var messageUI = AddMessageToUI(newMessage, true, timestamp);

                // Обновляем кэш UI
                if (!messageUICache.ContainsKey(currentChatId))
                {
                    messageUICache[currentChatId] = new List<UIElement>();
                }
                messageUICache[currentChatId].Add(messageUI);

                MessageTextBox.Clear();
            }
        }

        private void MessageTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(MessageTextBox.Text))
            {
                dbHelper.SetUserTyping(currentUserId, true);
            }
            else
            {
                dbHelper.SetUserTyping(currentUserId, false);
            }
        }

        private void SearchTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox.Text == "Поиск")
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void SearchTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Поиск";
                textBox.Foreground = Brushes.Gray;
            }
        }

        private void SettingsButton_Click(object sender, MouseButtonEventArgs e)
        {
            NavigationService?.Navigate(new SettingsPage(currentUserId, currentUserLogin, currentAvatarUrl));
        }

        private void ChatListBox_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (ChatListBox.SelectedItem != null)
            {
                var selectedItem = ChatListBox.SelectedItem as dynamic;
                string selectedChat = selectedItem.Login;
                int chatId = chatMapping[selectedChat];
                var favoriteChats = dbHelper.GetFavoriteChats(currentUserId).ToHashSet();

                ContextMenu contextMenu = new ContextMenu();
                MenuItem favoriteItem = new MenuItem
                {
                    Header = favoriteChats.Contains(chatId) ? "Убрать из избранного" : "Добавить в избранное"
                };
                favoriteItem.Click += (s, args) =>
                {
                    if (favoriteChats.Contains(chatId))
                    {
                        dbHelper.RemoveFavoriteChat(currentUserId, chatId);
                    }
                    else
                    {
                        dbHelper.AddFavoriteChat(currentUserId, chatId);
                    }
                    LoadChats();
                };
                contextMenu.Items.Add(favoriteItem);
                contextMenu.IsOpen = true;
            }
        }

        private void ToggleFavoriteMode_Click(object sender, RoutedEventArgs e)
        {
            isFavoriteMode = !isFavoriteMode;
            FavoriteButton.Content = isFavoriteMode ? "Все чаты" : "Избранное";
            LoadChats();
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            dbHelper.SetUserOnline(currentUserId, false);
            dbHelper.SetUserTyping(currentUserId, false);
        }
    }
}